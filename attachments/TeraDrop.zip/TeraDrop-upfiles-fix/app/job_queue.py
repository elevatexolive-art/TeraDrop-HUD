from __future__ import annotations

import asyncio
import itertools
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from app.settings import settings

log = logging.getLogger("teradrop.queue")


@dataclass
class _Job:
    priority: int
    sequence: int
    operation: Callable[[], Awaitable[Any]]
    future: asyncio.Future


class PriorityJobQueue:
    """Bounded priority queue: premium jobs enter ahead of free jobs.

    The queue owns the worker count, so resolver and download work never
    creates an unbounded task fan-out when many users send links at once.
    """

    def __init__(self) -> None:
        self._queue: asyncio.PriorityQueue[tuple[int, int, _Job]] = asyncio.PriorityQueue(
            maxsize=max(10, settings.max_queue_size)
        )
        self._sequence = itertools.count()
        self._workers: list[asyncio.Task] = []
        self._started = False

    async def start(self) -> None:
        if self._started:
            return
        self._started = True
        for index in range(max(1, min(settings.max_concurrent, 64))):
            self._workers.append(asyncio.create_task(self._worker(index)))

    async def stop(self) -> None:
        for worker in self._workers:
            worker.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()
        self._started = False

    async def submit(self, priority: int, operation: Callable[[], Awaitable[Any]]) -> Any:
        if not self._started:
            await self.start()
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        job = _Job(priority, next(self._sequence), operation, future)
        await self._queue.put((job.priority, job.sequence, job))
        return await future

    def size(self) -> int:
        return self._queue.qsize()

    async def _worker(self, index: int) -> None:
        while True:
            _, _, job = await self._queue.get()
            try:
                if not job.future.cancelled():
                    job.future.set_result(await job.operation())
            except asyncio.CancelledError:
                if not job.future.done():
                    job.future.cancel()
                raise
            except Exception as exc:
                if not job.future.done():
                    job.future.set_exception(exc)
                log.exception("worker %s failed", index)
            finally:
                self._queue.task_done()


JOB_QUEUE = PriorityJobQueue()


def priority_for(access: dict[str, Any]) -> int:
    if not access.get("premium"):
        return 30
    return {"v": 0, "s": 10, "r": 20}.get(str(access.get("plan_key")), 20)